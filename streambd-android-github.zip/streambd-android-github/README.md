# StreamBD — Free OTT App (Mobile & Android TV)
Copyright © 2026 Rifat Shad. All rights reserved.

## How to Build the APK (2 Ways)

### Option 1: Automatic Cloud Build on GitHub (No Android Studio Needed)
1. Create a new repository on GitHub (e.g., `streambd-app`).
2. Extract this ZIP and push all files (including the hidden `.github/workflows/build-apk.yml` folder) to the `main` branch.
3. Open your GitHub repository → click the **Actions** tab → click the **Build Android APK** workflow run.
4. Once finished (~2 minutes), download **StreamBD-Mobile-TV-APK** (`app-debug.apk`) from the **Artifacts** section and install it on your Android phone or Android TV!

### Option 2: Build Locally in Android Studio
1. Extract this ZIP and open the folder in **Android Studio**.
2. Let Gradle sync.
3. Click **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Find your APK at `app/build/outputs/apk/debug/app-debug.apk`.

## Native User-Agent Support
This Android wrapper exposes `AndroidBridge.setUserAgent(ua)` to the web app, so changing your User-Agent inside the app's **UA Menu** updates the native Android WebView `User-Agent` header directly.
